// Future: Level up logic
