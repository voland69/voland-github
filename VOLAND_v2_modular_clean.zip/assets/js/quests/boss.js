// Future: boss quests
