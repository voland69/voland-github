// Future: battle SFX
