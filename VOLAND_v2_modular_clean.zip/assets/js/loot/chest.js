// Future: chest opening
